<?php if(session()->has('success')): ?>
    <div class="alert alert-success mt-2" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(session('success')); ?>

    </div>
<?php elseif(session()->has('error')): ?>
    <div class="alert alert-success mt-2" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(session('error')); ?>

    </div>
<?php elseif($errors->any()): ?>
    <div class="alert alert-success mt-2" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        Masukan data dengan benar
    </div>
<?php endif; ?>
<?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/flash.blade.php ENDPATH**/ ?>