<?php $__env->startSection('main'); ?>
    <h1>Kategori</h1>
    <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary">Tambah Data</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Kategori</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($item->namaKategori); ?></td>
                <td><?php echo e($item->descKatrgori); ?></td>
                <td>
                    <a href="<?php echo e(route('kategori.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('kategori.destroy', $item->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/kategori/tampil.blade.php ENDPATH**/ ?>