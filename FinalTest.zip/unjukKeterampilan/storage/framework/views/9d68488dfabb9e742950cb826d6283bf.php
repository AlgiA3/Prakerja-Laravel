<?php $__env->startSection('main'); ?>
    <h1>Produk</h1>
    <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary">Tambah Data</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Produk</th>
                <th scope="col">Foto</th>
                <th scope="col">Harga Dibuat</th>
                <th scope="col">Deskrisi</th>
                <th scope="col">Kategori</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($item->namaProduk); ?></td>
                <td><img src="<?php echo e(asset('storage/'. $item->foto)); ?>" alt="" width="150px"></td>
                <td><?php echo e($item->harga); ?></td>
                <td><?php echo e($item->descProduk); ?></td>
                <td><?php echo e($item->kategori->namaKategori); ?></td>
                <td>
                    <a href="<?php echo e(route('produk.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('produk.destroy', $item->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/produk/tampil.blade.php ENDPATH**/ ?>