<?php $__env->startSection('tabel'); ?>
    <div>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                    <p class="card-text fs-6"><?php echo e($item->tanggalDibuat); ?></p>
                    <p class="card-text"><?php echo e(substr($item->isi, 0, 50)); ?></p>
                    <a href="<?php echo e(url('beranda/detail/'.$item->id)); ?>" class="btn btn-primary">Baca Lengkap</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templatefront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/dashboard/beranda.blade.php ENDPATH**/ ?>