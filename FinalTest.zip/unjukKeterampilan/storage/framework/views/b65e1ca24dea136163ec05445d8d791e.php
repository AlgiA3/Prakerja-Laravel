
    <div class="container">
        <div class="row" >
            <div class="col-lg-6" >
                <a href=<?php echo e(asset('dasboard')); ?>></a>
            </div>
        </div>
    </div>

<?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/artikel.blade.php ENDPATH**/ ?>