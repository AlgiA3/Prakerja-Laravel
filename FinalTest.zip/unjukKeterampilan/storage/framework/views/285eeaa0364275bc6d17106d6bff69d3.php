<?php $__env->startSection('main'); ?>
    <h1>User</h1>
    <table class="table mt-3">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama User</th>
                <th scope="col">Email</th>
                <th scope="col">Hak Akses</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td>
                        <form action="<?php echo e(route('user.update', $item->id)); ?>" method="post" class="row">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group col-6">
                                <select class="form-control" name="role">
                                    <option value="user" <?php if($item->role == 'user'): echo 'selected'; endif; ?>>User</option>
                                    <option value="editor" <?php if($item->role == 'editor'): echo 'selected'; endif; ?>>Editor</option>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <button class="btn btn-primary ">Simpan</button>
                            </div>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PraktekWeb\laravel\FinalTest\unjukKeterampilan\resources\views/user/tampil.blade.php ENDPATH**/ ?>